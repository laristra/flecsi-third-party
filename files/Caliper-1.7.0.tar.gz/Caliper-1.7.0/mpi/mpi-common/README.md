Caliper MPI library
================================

Miscellaneous MPI-specific Caliper functionality.
