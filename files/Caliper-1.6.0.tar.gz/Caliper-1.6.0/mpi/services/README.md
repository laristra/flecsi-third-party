MPI-specific services
========================================

This directory contains the MPI-specific parts of MPI-based services.
It will build libcaliper-mpiwrap.
