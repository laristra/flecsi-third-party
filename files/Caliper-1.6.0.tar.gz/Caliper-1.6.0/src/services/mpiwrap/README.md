This is the mpi-independent part of the MPI service that is compiled into libcaliper.
The mpi-specific part is in mpi/services/mpiwrap and will be compiled into 
libcaliper-mpiwrap.
