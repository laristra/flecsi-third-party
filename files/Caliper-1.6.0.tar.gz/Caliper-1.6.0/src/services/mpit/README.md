This is the mpi-independent part of the MPIT service that is compiled into libcaliper.
The mpi-specific part is in mpi/services/mpit.
