MPI-specific services
========================================

This directory contains the MPI-specific parts of the Caliper runtime system,
as well as MPI-based services. It will build libcaliper-mpi.
